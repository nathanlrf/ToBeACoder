package frequency_5;

public class test {

	
	public static void main(String[] args) {
		
	}
}
